<!DOCTYPE html>
<html>
<head>
	<title>Payment</title>
</head>
<body>
	<div style="background-image: url('opay.jpg');">
	<pre>
<!--form action="form.php" method="POST"-->
 <center><h1><u><i><font color="white">Payment Methods</i></font></u></h1></center>
 <center><!--div style="background-color: white"-->

 <button onclick="window.location.href ='https://pay.google.com/intl/en_in/about/?gclid=EAIaIQobChMI_ayRs_f65gIV2jUrCh0RfgO2EAAYASAAEgKPVvD_BwE';" >Google Pay</button><br>
<!--a href="https://pay.google.com/intl/en_in/about/?gclid=EAIaIQobChMI_ayRs_f65gIV2jUrCh0RfgO2EAAYASAAEgKPVvD_BwE">Google Pay</a-->
<button onclick="window.location.href = 'https://www.hdfcbank.com/personal/ways-to-bank/online-banking/net-banking';">Netbanking</button>
 <!--a href="https://www.hdfcbank.com/personal/ways-to-bank/online-banking/net-banking">Netbanking</a--><br>

  <button onclick="window.location.href = 'payment.php';">Card Payment</button>

 <!--a href="payment.php">Card Payment</a--><br><button onclick="window.location.href = 'https://paytm.com/login';">Paytm</button>

 <!--a href="https://paytm.com/login">Paytm</a--><br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>


 </center>
 </form>
</pre>
</div>
</body>
</html>